package com.interview.usersleepinginterval

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.app.AppOpsManager.OPSTR_GET_USAGE_STATS
import android.app.AppOpsManager
import android.content.Intent
import android.os.Process
import android.provider.Settings
import android.support.v4.app.AppOpsManagerCompat.MODE_ALLOWED
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.collections.HashMap


class MainActivity : AppCompatActivity() {
    val TAG = MainActivity::class.java.simpleName
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
            if (checkForPermission(this)) {
                val usageStatsManager: UsageStatsManager =
                    getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val calendar = Calendar.getInstance()
                val endTime = calendar.timeInMillis
                calendar.set(Calendar.DAY_OF_YEAR, -3)
                val fromTime = calendar.timeInMillis
                var usageStats =
                    usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, fromTime, endTime)
                usageStats = usageStats.filter { it.totalTimeInForeground > 0 }.sortedByDescending {
                    it.lastTimeStamp
                }
                val sleepingDuration = HashMap<Long, Long>()
                for (i in 0 until usageStats.size - 1) {
                    val startSleep = usageStats[i + 1].lastTimeStamp
                    val endSleep = usageStats[i].lastTimeStamp
                    val sleepingTimeInHrs =
                        (endSleep - startSleep) / (1000 * 60 * 60)
                    if (sleepingTimeInHrs > 2) {
                        sleepingDuration[startSleep] = endSleep
                    }
                }
                sleeping_time_rv.layoutManager = LinearLayoutManager(this@MainActivity)
                sleeping_time_rv.adapter = SleeperAdapter(sleepingDuration)

            } else {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
    }

    private fun checkForPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        return mode == MODE_ALLOWED
    }
}
