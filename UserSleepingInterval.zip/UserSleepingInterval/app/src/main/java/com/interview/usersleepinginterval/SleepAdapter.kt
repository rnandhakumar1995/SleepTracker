package com.interview.usersleepinginterval

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.sleeper_adapter.view.*
import java.util.*

class SleeperAdapter(var sleepingTime: HashMap<Long, Long>) : RecyclerView.Adapter<SleeperAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.sleeper_adapter, parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val elementAt = sleepingTime.keys.elementAt(position)
        holder.itemView.from_time_tv.text = Date(elementAt).toString()
        holder.itemView.end_time_tv.text = sleepingTime[elementAt]?.let { Date(it).toString() }
    }

    override fun getItemCount() = sleepingTime.keys.size
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val from_time_tv = itemView.findViewById<TextView>(R.id.from_time_tv)
        val end_time_tv = itemView.findViewById<TextView>(R.id.end_time_tv)
    }
}